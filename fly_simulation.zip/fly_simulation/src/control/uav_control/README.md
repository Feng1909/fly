### install ###
# casadi-3.6.3